package com.abhi.LocationBasedService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationBasedServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
